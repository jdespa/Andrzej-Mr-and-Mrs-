# For this test I have used create-react-app, Redux and Bootstrap
## For tests of components I have used Enzyme and provided Jest

- there are not many tests I have written
- there are async request has not been tested I found it a bit tricky and did not wanted to restructure the app (time issue)
- I had tested one action creator and 2 components

### In order to clear filters I have used old JS reload the page (not considerred in Production environment)

### I have spent on and off few hours to make to this point

### I have enjoyed the challenge, and needed to refresh my Redux knowledge


# IF THIS IS A PRODUCTION APP, I would do:
- Dockerfile, run this in docker container
- structure folders better
- better naming convention
- use more reusable components (esspecially DOM elements)
- add more tests
- add redux-thunk (or redux-promise) for async redux calls
